document.addEventListener('DOMContentLoaded', function() {
    const wrapper = document.getElementById('wrapper');
    const sidebar = document.getElementById('sidebar-wrapper');

    wrapper.style.paddingLeft = '5px';
    sidebar.remove();
}, false);
